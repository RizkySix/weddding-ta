

<?php $__env->startPush('style'); ?>
<style>
    @media (max-width: 991.98px) {
    .order-item {
      flex-direction: column; /* Mengatur tata letak menjadi kolom */
    }

    .image-hero {
        width: 300px
    }
  }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>


    <div class="main-content">
      <section class="section">
        <div class="container mt-5 mb-5">
            <div class="d-flex justify-content-center row">
                <div class="col-lg-10">
                    <div class="p-2">
                        <h4>Orderan Booking Kamu</h4>
                       
                    </div>
                    <div class="orders">
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="order-item d-flex justify-content-between align-items-center p-2 bg-white mt-4 px-3 rounded">
                            <div class="mr-1"><img class="image-hero rounded object-fit-cover" src="<?php echo e($order->booking->package->catalog[0]->path); ?>" width="100"></div>
                            <div class="d-flex flex-column align-items-center product-details"><span class="font-weight-bold"><?php echo e($order->product_name); ?></span>
                                <div class="d-flex flex-row product-desc">
                                    <div class="size mr-1"><span class="text-grey">Dari:</span><span class="font-weight-bold"> <?php echo e(\Carbon\Carbon::parse($order->booking->start_date)->format(' d M Y')); ?></span></div>
                                    ➡️
                                    <div class="color"><span class="text-grey">Sampai:</span><span class="font-weight-bold"><?php echo e(\Carbon\Carbon::parse($order->booking->end_date)->format(' d M Y')); ?></span></div>
                                </div>
                            </div>
                            <div class="d-flex flex-row align-items-center qty">
                               <?php if(!$order->reference || $order->reference->status == 'pending'): ?>
                               <h6 class="text-grey mt-1 mr-1 ml-1">Menunggu pembayaran</h6>
                               <?php elseif($order->reference->status == 'berhasil'): ?>
                               <h6 class="text-grey mt-1 mr-1 ml-1">Terbayar</h6>
                               <?php else: ?>
                               <h6 class="text-grey mt-1 mr-1 ml-1">Expired</h6>
                               <?php endif; ?>
                            </div>
                            <div>
                                <h5 class="text-grey"><?php echo money($order->total , 'IDR'); ?></h5>
                            </div>
                            <div class="d-flex align-items-center gap-2">
                                <a target="__blank" href="<?php echo e($order->payment_url); ?>">
                                    <i class="fa-brands fa-cc-amazon-pay" style="font-size: 21px;"></i>
                                </a>
    
                                <a type="button" data-bs-toggle="modal" data-bs-target="#detailOrder<?php echo e($order->id); ?>">
                                    <i class="fa-solid fa-eye" style="font-size: 21px;"></i>
                                </a>
                            </div>
                        </div>
                     
    
                        
                        <div class="modal fade" id="detailOrder<?php echo e($order->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                              <div class="modal-content">
                                <div class="modal-header">
                                  <h1 class="modal-title fs-5" id="exampleModalLabel">Detail order <?php echo e($order->product_name); ?></h1>
                                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <ul class="list-group">
                                        <li class="list-group-item d-flex align-items-center gap-2">
                                            <span class="material-icons mr-2 fw-bold">Order ID: </span> <?php echo e($order->order_id); ?>

                                        </li>
                                        <li class="list-group-item d-flex align-items-center gap-2">
                                            <span class="material-icons mr-2 fw-bold">Penyewa: </span> <?php echo e($order->buyer_name); ?>

                                        </li>
                                        <li class="list-group-item d-flex align-items-center gap-2">
                                            <span class="material-icons mr-2 fw-bold">Email: </span> <?php echo e($order->buyer_email); ?>

                                        </li>
                                        <li class="list-group-item d-flex align-items-center gap-2">
                                            <span class="material-icons mr-2 fw-bold">Handphone: </span> <?php echo e($order->buyer_phone); ?>

                                        </li>
                                        <li class="list-group-item d-flex align-items-center gap-2">
                                            <span class="material-icons mr-2 fw-bold">Lokasi sewa: </span> <?php echo e($order->buyer_address); ?>

                                        </li>
                                        <li class="list-group-item d-flex align-items-center gap-2">
                                            <span class="material-icons mr-2 fw-bold">Status pesanan: </span>
                                            <?php if(!$order->reference || $order->reference->status == 'pending'): ?>
                                           Menunggu pembayaran
                                            <?php elseif($order->reference->status == 'berhasil'): ?>
                                           Terbayar
                                            <?php else: ?>
                                           Expired
                                            <?php endif; ?>
                                        </li>

                                        <?php if(!$order->reference || $order->reference->status == 'pending'): ?>
                                        <li class="list-group-item d-flex align-items-center gap-2">
                                            <span class="material-icons mr-2 fw-bold">Expired pada: </span>
                                             <?php echo e(\Carbon\Carbon::parse($order->expired_at)->format('d M Y')); ?>

                                           
                                        </li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                </div>
                              </div>
                            </div>
                          </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                   
                </div>
            </div>
        </div>
      </section>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer.partial.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ta-wedding-decoration\resources\views/customer/order-item.blade.php ENDPATH**/ ?>