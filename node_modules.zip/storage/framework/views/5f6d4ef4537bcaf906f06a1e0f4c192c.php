<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container">
        <?php echo $__env->yieldContent('package'); ?>
    </div>
<?php $__env->stopSection(); ?><?php /**PATH C:\laragon\www\ta-wedding-decoration\resources\views/package/components/main.blade.php ENDPATH**/ ?>