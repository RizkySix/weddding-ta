<nav class="navbar bg-body-tertiary">
    <div class="container">
      <a class="navbar-brand" href="#">
        <img src="/docs/5.3/assets/brand/bootstrap-logo.svg" alt="Bootstrap" width="30" height="24">
      </a>
    </div>
  </nav><?php /**PATH C:\laragon\www\ta-wedding-decoration\resources\views/cust-components/navbar.blade.php ENDPATH**/ ?>