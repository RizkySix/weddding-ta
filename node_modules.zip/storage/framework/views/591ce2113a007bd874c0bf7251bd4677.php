

<?php $__env->startSection('content'); ?>

    <div class="main-content">
       <section class="section">
        <div class="section-header" style="display: flex; flex-direction: column">
            <h3>Data Paket</h3>
            <span class="blue-text">Lengkapi form-form dibawah dengan benar dan detail, form dengan tanda * merupakan form yang wajib. Jika belum ada decoration yang dipilih paket tidak akan ditampilkan pada halaman Customer.</span>
        </div>
     
        <div class="section-body">
               
               
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>Berikut Data Order......</h4>
                            <div class="card-header-form d-flex">

                                <form action="/admin/customer" method="GET">
                                    <div class="input-group">
                                        <input type="text"
                                            class="form-control"
                                            name="search"
                                            placeholder="Cari berdasarkan nama...">
                                        <div class="input-group-btn">
                                            <button class="btn btn-primary"><i class="fas fa-search"></i></button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table-striped table">
                                    <tr>
                                        <th>
                                            No
                                        </th>
                                        <th>Nama</th>
                                        <th>Email</th>
                                        <th>Tanggal Bergabung</th>
                
                                        <th>Order Dibuat</th>
                                        <th>Order Closing</th>
                                       
                                    </tr>
                                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="p-0 text-center">
                                           <?php echo e($loop->iteration); ?>

                                        </td>
                                        <td><?php echo e($customer->name); ?></td>
                                        <td><?php echo e($customer->email); ?></td>
                                     
                                        <td><?php echo e(\Carbon\Carbon::parse($customer->created_at)->format('D d M Y')); ?></td>
                                        <td><?php echo e($customer->order()->count()); ?></td>
                                        <td><?php echo e($customer->paid); ?></td>
                                

                                            
                                       
                                    </tr>

                                    

                                    
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>

                                <div class="p-4">
                                    <?php echo e($customers->links()); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
         
        </div>
        

        <?php $__env->startPush('modal'); ?>
        <div class="modal fade" id="detailOrder" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content" id="modalContent">
              
              </div>
            </div>
          </div>
        <?php $__env->stopPush(); ?>

       </section>
    </div>
    <?php $__env->startPush('scripts'); ?>
         <!-- JS Libraies -->
    <script src="<?php echo e(asset('dist/library/jquery-ui-dist/jquery-ui.min.js')); ?>"></script>

    <!-- Page Specific JS File -->
    <script src="<?php echo e(asset('dist/js/page/components-table.js')); ?>"></script>
    
  
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ta-wedding-decoration\resources\views/admin/customer.blade.php ENDPATH**/ ?>