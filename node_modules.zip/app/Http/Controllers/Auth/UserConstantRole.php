<?php
namespace App\Http\Controllers\Auth;

class UserConstantRole {
    public const CUSTOMER = 'customer';
    public const ADMIN = 'admin';
    public const EMPLOYEE = 'pegawai';
}